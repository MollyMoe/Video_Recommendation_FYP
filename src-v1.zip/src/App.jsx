 import { createBrowserRouter, RouterProvider, Route } from "react-router-dom";
import HomePage from './pages/HomePage';
import InputGenrePage from './pages/InputGenrePage';
import MainLayout from './layouts/MainLayout';
import HistoryPage from "./pages/HistoryPage";
import SignUpPage from "./pages/SignUpPage";
import SignInPage from "./pages/SignInPage";
import ResetPasswordPage from "./pages/ResetPasswordPage";

const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: "/history",
        element: <HistoryPage />,
      },
    ],
  },
  { // Not using MainLayout
    path: "/inputgenre",element: <InputGenrePage />, 
  },
  {
    path: "/signup", element:<SignUpPage />
  },
  {
    path:"/signin", element:<SignInPage />
  },
  {
    path:"/reset-password", element:<ResetPasswordPage />
  }
]);


function App() {
  return <RouterProvider router={router} />
}

export default App;


    
    